print 5
