a = set()
b = {1, 2}
c = {"AB", "CD"}
# Below uses SET_UPDATE
d = {1, 2, 3, 4}
