ustr = u'Unicode'
bstr = b'Bytes'
dstr = 'Default'
