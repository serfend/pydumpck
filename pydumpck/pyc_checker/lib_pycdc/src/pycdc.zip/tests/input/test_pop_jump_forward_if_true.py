if not 1 == 0:
	print('not true')
print('true (so jumping forward)')
