import sys
import os

sys.stdout.write('Test\n')
sys.stdout.write(os.path.join('foo', 'bar'))

print('\n')
print(eval('4 * 13'))
print()
